@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
title NUNES IndiaMART - REUSE Existing Chrome Login
echo.
echo ================================================================
echo  NUNES INDIAMART - CONNECT THE CHROME YOU ALREADY LOGGED INTO
echo ================================================================
echo  DO NOT close your current Chrome or sign out of IndiaMART.
echo  No special Chrome profile, OTP, cookie file or re-login needed.
echo  One-time setup: Load the included Chrome extension using
echo  chrome://extensions and paste the local pairing code printed below.
echo  Next time: just double-click this BAT with the same Chrome profile.
echo ================================================================
echo.
set "PY_CMD="
where py >nul 2>&1 && set "PY_CMD=py"
if not defined PY_CMD (
    where python >nul 2>&1 && set "PY_CMD=python"
)
if not defined PY_CMD (
    echo Python was not found. Install Python 3.11 or newer from python.org,
    echo check "Add Python to PATH", then double-click this BAT again.
    pause
    exit /b 1
)
if not exist "windows\INDIAMART_EXISTING_CHROME_BRIDGE.py" (
    echo Missing Windows bridge file. Extract the WHOLE ZIP first,
    echo keeping its windows and existing_chrome_extension folders together.
    pause
    exit /b 2
)
if not exist "seller_account.py" (
    echo The seller parser is missing. Extract the complete ZIP.
    pause
    exit /b 2
)
if not exist "windows\INDIAMART_ACCOUNT_SYNC.py" (
    echo The catalogue PDF sync engine is missing. Extract the complete ZIP.
    pause
    exit /b 2
)
echo Checking the only Python dependency needed for PDF downloads...
%PY_CMD% -c "import requests" >nul 2>&1
if errorlevel 1 (
    %PY_CMD% -m pip install --disable-pip-version-check requests
    if errorlevel 1 (
        echo Could not install requests. Verify Internet/Python and retry.
        pause
        exit /b 1
    )
)
echo.
echo If Chrome extension is not installed yet:
echo  1. In the SAME Chrome where you are already signed into IndiaMART,
echo     go to chrome://extensions.
echo  2. Enable Developer mode and click Load unpacked.
echo  3. Select the existing_chrome_extension folder from this ZIP.
echo  4. Open the extension and enter the pairing code below ONCE.
echo  5. In your current IndiaMART tab open Manage Products.
echo  6. Click Scan Seller Products; optionally enable hourly scan.
echo.
echo Your local output folder will be:
echo %%LOCALAPPDATA%%\NunesCatalogue\IndiaMART\ExistingChrome\Catalogues
echo.
echo Starting paired LOCAL bridge now. Keep this window open.
echo No account passwords or cookie data are collected or uploaded.
echo.
%PY_CMD% windows\INDIAMART_EXISTING_CHROME_BRIDGE.py
set "RESULT=%ERRORLEVEL%"
echo.
echo Local bridge exited with code %RESULT%.
pause
exit /b %RESULT%
