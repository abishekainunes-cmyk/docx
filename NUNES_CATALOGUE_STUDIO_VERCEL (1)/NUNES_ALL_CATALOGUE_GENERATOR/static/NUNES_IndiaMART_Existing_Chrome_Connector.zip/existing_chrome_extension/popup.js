"use strict";
const $=id=>document.getElementById(id);
let paired=false;
function message(value,type=""){
  const box=$("status");
  box.textContent=String(value||"");
  box.className=type;
}
async function ask(type,data={}){
  const response=await chrome.runtime.sendMessage({type,...data});
  if(!response?.ok)throw Error(response?.error||"Local connector request failed");
  return response.result;
}
async function refresh(){
  try{
    const state=await ask("NUNES_STATUS");
    paired=Boolean(state.paired);
    $("pairButton").textContent=paired?"Reconnect with Pairing Code":"Connect to Windows Runner";
    $("scan").disabled=!paired||Boolean(state.activeRun)||Boolean(state.pausedRun);
    $("stop").disabled=!state.activeRun&&!state.pausedRun;
    $("pause").disabled=!state.activeRun;
    $("resume").disabled=!state.pausedRun;
    $("hourly").disabled=!paired;
    $("hourly").checked=Boolean(state.hourlyEnabled);
    const receiver=state.receiver;
    if(!paired){
      message("Start the Windows runner and paste its pairing code here.");
      $("counts").textContent="";
      return;
    }
    if(!receiver||receiver.receiver==="offline"){
      message(receiver?.message||"Windows runner is not open.", "error");
      $("counts").textContent="";
      return;
    }
    const active=state.activeRun;
    const scanned=receiver.captured_products||0;
    const pages=receiver.pages_scanned||0;
    $("counts").textContent=scanned+" product(s) from "+pages+" page(s)";
    if(active){
      message("Scan active! Keep your already logged-in IndiaMART tab open. Page "+
        (active.pages+1)+" of up to "+active.maxPages+".","success");
    }else if(state.pausedRun){
      message("Scan paused after "+state.pausedRun.pages+
        " page(s). Click Resume to continue the same authorized tab; Stop to finish saved pages.","success");
    }else if(receiver.pdf_state==="generating"||receiver.pdf_state==="queued"){
      message("Seller products captured. Full/Mini PDFs are generating on your Windows PC.","success");
    }else if(receiver.pdf_state==="finished"){
      message("Catalogue sync completed! Check your Catalogues output folder.","success");
    }else if(receiver.pdf_state==="error"){
      message("PDF generation needs attention. Check the Windows runner window.","error");
    }else if(state.onManageTab){
      message("Manage Products tab detected! Click 'Scan Seller Products' to begin.","success");
    }else{
      message("Windows runner paired! Open your IndiaMART Manage Products tab in this Chrome window, then click Scan.","success");
    }
  }catch(e){
    message(String(e.message||e),"error");
    $("scan").disabled=true;$("hourly").disabled=true;
  }
}
$("pairButton").onclick=async()=>{
  const code=$("pair").value.trim().replace(/^["']|["']$/g,"");
  if(!code){
    message("Paste the pairing code printed in your Windows runner window.","error");
    return;
  }
  $("pairButton").disabled=true;
  message("Connecting to Windows runner...","");
  try{
    await ask("NUNES_PAIR",{code});
    $("pair").value="";
    message("Paired successfully with Windows runner! No IndiaMART login required.","success");
    await refresh();
  }catch(e){message(e.message,"error");}
  finally{$("pairButton").disabled=false;}
};
if($("openFolder")){
  $("openFolder").onclick=async()=>{
    try{await ask("NUNES_OPEN_FOLDER");}catch(_){}
  };
}
$("scan").onclick=async()=>{
  $("scan").disabled=true;
  try{
    const r=await ask("NUNES_START");
    message(r.message||"Scanning the signed-in seller page…","success");
    await refresh();
  }catch(e){message(e.message,"error");$("scan").disabled=false;}
};
$("pause").onclick=async()=>{
  $("pause").disabled=true;
  try{
    const result=await ask("NUNES_PAUSE");
    message(result.message||"Paused.","success");
    await refresh();
  }catch(e){message(e.message,"error");$("pause").disabled=false;}
};
$("resume").onclick=async()=>{
  $("resume").disabled=true;
  try{
    const result=await ask("NUNES_RESUME");
    message(result.message||"Resumed.","success");
    await refresh();
  }catch(e){message(e.message,"error");$("resume").disabled=false;}
};
$("stop").onclick=async()=>{
  $("stop").disabled=true;
  try{await ask("NUNES_STOP");await refresh();}
  catch(e){message(e.message,"error");$("stop").disabled=false;}
};
$("hourly").onchange=async()=>{
  const enabled=$("hourly").checked;
  $("hourly").disabled=true;
  try{
    await ask("NUNES_SET_HOURLY",{enabled});
    await refresh();
  }catch(e){message(e.message,"error");$("hourly").checked=!enabled;}
  finally{$("hourly").disabled=!paired;}
};
refresh();
setInterval(refresh,4000);
