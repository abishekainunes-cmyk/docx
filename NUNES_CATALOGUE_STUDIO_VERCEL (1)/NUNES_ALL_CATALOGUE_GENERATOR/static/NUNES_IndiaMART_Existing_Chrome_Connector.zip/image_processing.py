"""Safely remove the background from an uploaded product photo before PDF use.

Uses rembg's u2netp model when available. In constrained serverless deployments,
a safe Pillow-only fallback removes contiguous nearly-white studio backgrounds.
Complex backgrounds without the model fail explicitly; never fake a cutout.
"""
import io
from collections import deque
import os
import tempfile
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageOps, UnidentifiedImageError

MAX_IMAGE_BYTES = 3_000_000
MAX_IMAGE_PIXELS = 15_000_000
MAX_SIDE = 1200


class BackgroundRemovalError(ValueError):
    pass


class BackgroundRemovalUnavailable(RuntimeError):
    pass


@lru_cache(maxsize=1)
def _session():
    # Vercel's deployment bundle is read-only; /tmp is writable.
    if os.environ.get("VERCEL") and not os.environ.get("U2NET_HOME"):
        os.environ["U2NET_HOME"] = os.path.join(tempfile.gettempdir(), "nunes_rembg_models")
    try:
        from rembg import new_session
        return new_session("u2netp")
    except Exception as exc:
        # Expose only the exception *type*, never a system path or
        # third-party response body, to help isolate serverless incompatibility.
        raise BackgroundRemovalUnavailable(
            "Background removal model could not start ("+type(exc).__name__+"). "
            "The original background was not used."
        ) from exc


def _white_studio_background_cutout(picture: Image.Image) -> bytes:
    """Pillow fallback ONLY for demonstrably uniform light studio backgrounds.

    This is a real transparency mask made by edge-connected flood fill,
    not a decorative white rectangle or an unprocessed image.
    Complex or patterned backgrounds are rejected, not misrepresented.
    """
    rgba=picture.convert("RGBA")
    w,h=rgba.size
    alpha=rgba.getchannel("A").getextrema()
    if alpha and alpha[0] < 255:
        output=io.BytesIO()
        rgba.save(output,format="PNG")
        return output.getvalue()
    rgb=rgba.convert("RGB").tobytes()
    def is_background(index):
        at=index*3
        r,g,b=rgb[at],rgb[at+1],rgb[at+2]
        return min(r,g,b)>=220 and max(r,g,b)-min(r,g,b)<=38
    sample=[]
    step_x=max(1,w//45)
    step_y=max(1,h//45)
    for x in range(0,w,step_x):
        sample.extend((x,(h-1)*w+x))
    for y in range(0,h,step_y):
        sample.extend((y*w,y*w+w-1))
    if not sample or sum(is_background(idx) for idx in sample)/len(sample)<0.88:
        raise BackgroundRemovalUnavailable(
            "This image has a complex background. A full rembg cutout worker "
            "is required; please use a clear white-background product photo."
        )
    mask=bytearray(b"\xff")*(w*h)
    queue=deque()
    def add(idx):
        if mask[idx] and is_background(idx):
            mask[idx]=0
            queue.append(idx)
    for idx in sample:
        add(idx)
    while queue:
        idx=queue.popleft()
        x=idx%w
        if x>0:add(idx-1)
        if x+1<w:add(idx+1)
        if idx>=w:add(idx-w)
        if idx+w<w*h:add(idx+w)
    clear=mask.count(0)
    if clear < 0.06*w*h:
        raise BackgroundRemovalUnavailable(
            "No clean removable studio background was detected."
        )
    rgba.putalpha(Image.frombytes("L",(w,h),bytes(mask)))
    output=io.BytesIO()
    rgba.save(output,format="PNG",optimize=True)
    return output.getvalue()


def process_upload(raw: bytes) -> bytes:
    """Return a transparent PNG. Reject oversized/unsupported files."""
    if not isinstance(raw, bytes) or not raw or len(raw) > MAX_IMAGE_BYTES:
        raise BackgroundRemovalError("Image must be smaller than 3 MB.")
    try:
        with Image.open(io.BytesIO(raw)) as image:
            if image.format not in ("JPEG", "PNG", "WEBP"):
                raise BackgroundRemovalError("Only JPEG, PNG and WebP are supported.")
            if image.width * image.height > MAX_IMAGE_PIXELS:
                raise BackgroundRemovalError("Image resolution exceeds 15 megapixels.")
            picture = ImageOps.exif_transpose(image).convert("RGBA")
            picture.thumbnail((MAX_SIDE, MAX_SIDE), Image.Resampling.LANCZOS)
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError) as exc:
        raise BackgroundRemovalError("Uploaded image is damaged or unsupported.") from exc

    if picture.getchannel("A").getextrema()[0] < 255:
        return _white_studio_background_cutout(picture)
    stream=io.BytesIO()
    picture.save(stream,format="PNG",optimize=True)
    try:
        from rembg import remove
        result=remove(stream.getvalue(),session=_session())
        with Image.open(io.BytesIO(result)) as transparent:
            transparent=transparent.convert("RGBA")
            if transparent.getchannel("A").getextrema()==(255,255):
                raise BackgroundRemovalUnavailable("Model did not separate the background.")
            output=io.BytesIO()
            transparent.save(output,format="PNG",optimize=True)
            return output.getvalue()
    except Exception as error:
        # When the optional rembg/onnxruntime libraries or model cannot load
        # on Vercel, real studio-background removal still works with Pillow.
        # Never pretend that a busy scene was removed when it was not.
        try:
            return _white_studio_background_cutout(picture)
        except BackgroundRemovalUnavailable as fallback_error:
            raise BackgroundRemovalUnavailable(
                "The image needs the rembg model for this complex background "
                "(engine: "+type(error).__name__+"). "
                "Use a studio-white photo or an instance with rembg installed."
            ) from fallback_error

def write_transparent_png(raw: bytes) -> Path:
    png = process_upload(raw)
    fd, name = tempfile.mkstemp(prefix="nunes_cutout_", suffix=".png")
    try:
        with os.fdopen(fd, "wb") as file:
            file.write(png)
    except BaseException:
        Path(name).unlink(missing_ok=True)
        raise
    return Path(name)


def _light_colored_background_cutout(picture):
    """Conservative cutout for near-uniform light blue/gray studio backdrops.

    Use a sampled median edge color and flood-fill ONLY edge-connected pixels
    close to that color. No object segmentation is pretended for complex scenes.
    """
    rgba=picture.convert("RGBA")
    w,h=rgba.size
    rgb=rgba.convert("RGB").tobytes()
    sample=[]
    sx=max(1,w//40);sy=max(1,h//40)
    sample.extend(x for x in range(0,w,sx))
    sample.extend((h-1)*w+x for x in range(0,w,sx))
    sample.extend(y*w for y in range(0,h,sy))
    sample.extend(y*w+w-1 for y in range(0,h,sy))
    sample=list(dict.fromkeys(sample))
    if len(sample)<8:
        raise BackgroundRemovalUnavailable("Insufficient border information")
    import statistics
    rr=[rgb[3*i] for i in sample]
    gg=[rgb[3*i+1] for i in sample]
    bb=[rgb[3*i+2] for i in sample]
    color=(int(statistics.median(rr)),int(statistics.median(gg)),
           int(statistics.median(bb)))
    # Avoid falsely stripping dark/busy backgrounds or pale-colored products.
    if min(color)<175 or max(color)-min(color)>95:
        raise BackgroundRemovalUnavailable("Complex background")
    threshold=25
    def match(i):
        a=i*3
        return (abs(rgb[a]-color[0])<=threshold and
                abs(rgb[a+1]-color[1])<=threshold and
                abs(rgb[a+2]-color[2])<=threshold)
    if sum(match(i) for i in sample)/len(sample)<0.91:
        raise BackgroundRemovalUnavailable("Nonuniform background")
    alpha=bytearray(b"\xff")*(w*h)
    queue=deque()
    def add(i):
        if alpha[i] and match(i):
            alpha[i]=0
            queue.append(i)
    for i in sample:add(i)
    while queue:
        i=queue.popleft()
        x=i%w
        if x>0:add(i-1)
        if x<w-1:add(i+1)
        if i>=w:add(i-w)
        if i+w<w*h:add(i+w)
    if alpha.count(0)<0.08*w*h:
        raise BackgroundRemovalUnavailable("Insufficient background removed")
    rgba.putalpha(Image.frombytes("L",(w,h),bytes(alpha)))
    output=io.BytesIO()
    rgba.save(output,format="PNG",optimize=True)
    return output.getvalue()


def save_original_mini_image(raw):
    """Validated original when a complex upload cannot be cut out safely."""
    if not isinstance(raw,bytes) or not raw or len(raw)>MAX_IMAGE_BYTES:
        raise BackgroundRemovalError("Mini photo must be under 3 MB.")
    try:
        with Image.open(io.BytesIO(raw)) as opened:
            if opened.format not in ("JPEG","PNG","WEBP"):
                raise BackgroundRemovalError("Only JPEG, PNG and WebP are supported.")
            if opened.width*opened.height>MAX_IMAGE_PIXELS:
                raise BackgroundRemovalError("Image exceeds 15 megapixels.")
            picture=ImageOps.exif_transpose(opened).convert("RGBA")
            picture.thumbnail((760,760),Image.Resampling.LANCZOS)
        fd,name=tempfile.mkstemp(prefix="nunes_mini_original_",suffix=".png")
        try:
            with os.fdopen(fd,"wb") as output:
                picture.save(output,format="PNG",optimize=True)
        except BaseException:
            Path(name).unlink(missing_ok=True)
            raise
        return Path(name)
    except (OSError,UnidentifiedImageError,Image.DecompressionBombError) as exc:
        raise BackgroundRemovalError("Invalid mini photo") from exc

def prepare_mini_product_image(image_path):
    """Make a real transparent product cutout for Mini Catalogue PDF cards.

    Runs on Vercel with Pillow only (no Ollama, AI credits or downloaded
    rembg weights). Conservative connected-edge masking is safe for studio
    white/light backgrounds; complex backgrounds are retained unchanged.
    Returns (image_path, background_removed). Never fails a whole catalogue.
    The output PNG is tightly cropped so the product fills its gallery card.
    """
    import hashlib
    image_path=Path(image_path)
    try:
        with Image.open(image_path) as opened:
            if opened.width*opened.height>MAX_IMAGE_PIXELS:
                return image_path,False
            picture=ImageOps.exif_transpose(opened).convert("RGBA")
            # Keep multi-product PDF generation bounded on a serverless host.
            picture.thumbnail((680,680),Image.Resampling.LANCZOS)
        if min(picture.size)<40:
            return image_path,False
        # The studio cutter preserves existing transparency and removes only
        # a uniform edge-connected background, not arbitrary colored objects.
        try:
            rendered=_white_studio_background_cutout(picture)
        except BackgroundRemovalUnavailable:
            rendered=_light_colored_background_cutout(picture)
        with Image.open(io.BytesIO(rendered)) as result:
            result=result.convert("RGBA")
            alpha=result.getchannel("A")
            extrema=alpha.getextrema()
            if not extrema or extrema[0]==255:
                return image_path,False
            # Trim transparent margins (6% padding) for balanced PDF cards.
            bounds=alpha.point(lambda v: 255 if v>12 else 0).getbbox()
            if not bounds:
                return image_path,False
            left,top,right,bottom=bounds
            margin=max(8,int(max(right-left,bottom-top)*0.055))
            left=max(0,left-margin);top=max(0,top-margin)
            right=min(result.width,right+margin)
            bottom=min(result.height,bottom+margin)
            cropped=result.crop((left,top,right,bottom))
            # Reject almost blank / degenerate masks.
            if cropped.width<40 or cropped.height<40:
                return image_path,False
            unique_key=hashlib.sha256(image_path.read_bytes()).hexdigest()[:22]
            dest=Path(tempfile.gettempdir())/("nunes_mini_cutout_"+unique_key+".png")
            if not dest.exists():
                cropped.save(dest,format="PNG",optimize=True)
            return dest,True
    except (OSError,ValueError,UnidentifiedImageError,BackgroundRemovalUnavailable,
            Image.DecompressionBombError):
        return image_path,False
