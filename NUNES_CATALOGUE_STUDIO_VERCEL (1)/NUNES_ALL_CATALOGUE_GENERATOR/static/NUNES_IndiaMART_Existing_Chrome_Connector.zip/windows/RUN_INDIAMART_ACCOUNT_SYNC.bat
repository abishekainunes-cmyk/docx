@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0.."
title NUNES IndiaMART Seller - Normal Login and Persistent Sync
echo.
echo ============================================================
echo  NUNES INDIA MART SELLER - CONNECT AND STAY SIGNED IN
echo ============================================================
echo  NORMAL LOGIN: Official IndiaMART Chrome window on this PC.
echo  The separate NUNES Chrome profile remembers the session while
echo  IndiaMART permits it. No password, OTP or cookies are uploaded.
echo.
echo  VTech / VT are catalogue labels ONLY. Source names remain.
echo ============================================================
echo.
echo [1] Login normally ONCE + scan products every hour (recommended)
echo [2] Login normally + scan and generate once
echo [3] Import a seller CSV/JSON instead (optional fallback)
echo.
set "SYNC_MODE=1"
set /p "SYNC_MODE=Select 1, 2 or 3 [1]: "
if "%SYNC_MODE%"=="" set "SYNC_MODE=1"
if not "%SYNC_MODE%"=="1" if not "%SYNC_MODE%"=="2" if not "%SYNC_MODE%"=="3" (
  echo Invalid selection.
  pause
  exit /b 2
)
where py >nul 2>&1
if errorlevel 1 (
  echo Python was not found. Install Python 3.11 or newer.
  echo Enable the Python launcher (py) and rerun this BAT.
  pause
  exit /b 1
)
set "NUNES_LOCAL_DATA=%LOCALAPPDATA%\NunesCatalogue\IndiaMART"
set "NUNES_PROFILE=%NUNES_LOCAL_DATA%\ChromeProfile"
set "NUNES_CAPTURE=%NUNES_LOCAL_DATA%\seller_products.json"
set "NUNES_OUTPUT=%~dp0..\NUNES_Account_Catalogues"
if not exist "%NUNES_LOCAL_DATA%" mkdir "%NUNES_LOCAL_DATA%"
if not exist "%NUNES_OUTPUT%" mkdir "%NUNES_OUTPUT%"
echo Installing/checking local requirements...
py -m pip install --quiet --disable-pip-version-check requests playwright
if errorlevel 1 (
  echo Could not install requests and Playwright. Check Internet/Python.
  pause
  exit /b 1
)
echo.
if "%SYNC_MODE%"=="3" goto IMPORT_FILE
echo Your dedicated NUNES Chrome window will open.
echo Sign in to the official IndiaMART site normally.
echo Complete OTP on the IndiaMART page, then open Manage Products.
echo Return to this window and press Enter ONLY after the list loads.
echo.
echo Keep this command window open for hourly auto-sync.
echo A logged-out IndiaMART session may require signing in again.
echo.
if "%SYNC_MODE%"=="1" (
  py windows\INDIAMART_ACCOUNT_SYNC.py --capture-seller --input "%NUNES_CAPTURE%" --output "%NUNES_OUTPUT%" --profile "%NUNES_PROFILE%" --watch-seconds 3600
) else (
  py windows\INDIAMART_ACCOUNT_SYNC.py --capture-seller --input "%NUNES_CAPTURE%" --output "%NUNES_OUTPUT%" --profile "%NUNES_PROFILE%"
)
goto FINISH
:IMPORT_FILE
echo Enter the path to your own optional CSV/JSON export.
set "INDIAMART_FILE="
set /p "INDIAMART_FILE=CSV/JSON file path: "
if not exist "%INDIAMART_FILE%" (
  echo File not found. No data imported.
  pause
  exit /b 1
)
py windows\INDIAMART_ACCOUNT_SYNC.py --input "%INDIAMART_FILE%" --output "%NUNES_OUTPUT%"
:FINISH
echo.
echo PDF files and checkpoints: %NUNES_OUTPUT%
echo Chrome sign-in profile stays LOCAL: %NUNES_PROFILE%
echo This system NEVER asks you to type an IndiaMART password here.
pause
