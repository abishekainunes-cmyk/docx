NUNES INDIA MART — EXISTING CHROME CONNECTOR
=================================================
Release: Existing signed-in Chrome; READ-ONLY seller product collection.
Project: https://github.com/aiabishekgv-stack/Catalogue-Generator
Website: https://nunes-catalogue-studio-live.vercel.app/catalogue
No IndiaMART password, OTP, session cookie or Chrome profile is copied.

ONE-TIME INSTALLATION
1. Extract this complete ZIP into a folder you own, such as
   C:\NUNES_IndiaMART_Existing_Chrome_Connector.
   Keep the windows and existing_chrome_extension subfolders together.
2. Install Python 3.11+ with the Windows "py" launcher if needed.
3. Double-click RUN_EXISTING_CHROME_CONNECTOR.bat in the extracted folder.
   The BAT checks Python, installs requests if necessary, then starts a local
   server on 127.0.0.1:8765. Leave its command window open.
4. In the SAME Google Chrome profile where your IndiaMART seller account is
   already signed in, open chrome://extensions.
5. Turn on Developer mode. Click "Load unpacked".
6. Select the folder windows\existing_chrome_extension.
7. Pin the NUNES connector extension and click its toolbar icon.
8. Paste the local pairing code shown by the BAT window once.
   This is a LOCAL pairing code, NOT your IndiaMART login/OTP.
9. In the already signed-in Chrome tab, open IndiaMART Seller → Manage
   Products. Do NOT close Chrome and do NOT sign in again if already signed in.
10. In the extension popup click "Scan Seller Products".
11. Enable "Auto-sync hourly" if desired. Chrome and the local BAT must
    remain running; the official IndiaMART login must still be valid.

WHAT HAPPENS
- The extension reads visible product titles, public listing links, images
  and supported non-sensitive fields from the authorized Manage Products tab.
- The local receiver stages the new scan. An empty/failed scan cannot delete
  the last successful product collection.
- A successful capture saves seller_products.json and triggers source-backed
  Full/Mini PDF generation through your existing hosted NUNES site.
- Incomplete product evidence produces a clearly marked REVIEW DRAFT, not an
  invented source specification.
- Original manufacturers and source model numbers remain separate from the
  house catalogue brand (VTech) and catalogue model/series (VT).
- IndiaMART prices and products are NEVER changed by this connector.

SAVED FILES
%LOCALAPPDATA%\NunesCatalogue\IndiaMART\ExistingChrome\
  seller_products.json        Last captured products
  scan-checkpoint.json        Current scan pages for troubleshooting/resume
  connection-status.json      Last local status (no pairing code)
  local-pairing.json          LOCAL SECRET — do not share this file
  Catalogues\
    Catalogue\               One Full PDF per source product or review draft
    Mini Catalogue\          Batched Mini PDFs
    sync-checkpoint.json      Skip unchanged products; retry failed
    last-report.json          Generated vs. review-required status
The console prints the output folder as well.

SECURITY AND LIMITATIONS
- The Vercel website cannot silently attach to existing Chrome tabs.
  Chrome requires one-time extension installation and user authorization.
- Never paste an IndiaMART password, OTP or private Chrome cookie into NUNES.
- The collector is read-only and never opens edit/delete/price actions.
- Seller page selectors are best-effort and can change with IndiaMART updates.
  If a scan finds zero product names, open the real Manage Products page and
  verify it is loaded; your prior captured products stay safe.
- An expired account session requires normal manual IndiaMART sign-in.
- Product photographs must match the exact model. Missing photos remain
  missing or are explicitly marked for review.
- The local status uses http://127.0.0.1:8765/health and indicates real
  captured rows only after the extension has scanned them. It is not proof of
  authenticated access until a real scan succeeds.
- The pairing is preserved locally. Never publish local-pairing.json.

TROUBLESHOOTING
- "py is not recognized": install Python 3.11+ and Windows Python launcher.
- "Cannot bind port 8765": close a duplicate NUNES connector command window.
- "Refresh Manage Products": Chrome extensions cannot access a tab that
  predates installation until that tab is reloaded. Refresh that tab.
- "Login required": sign in directly on the official IndiaMART website.
- "No product titles": IndiaMART might have changed the page layout; the
  extension needs selector updates based on the actual page.
- "Failed PDF": check Catalogues\last-report.json and the local terminal.
  Retry later; completed source PDFs are not supposed to be repeated.

OPTIONAL LEGACY FALLBACK
windows\RUN_INDIAMART_ACCOUNT_SYNC.bat opens a separate dedicated Chrome
profile with Playwright. It is NOT the same existing-Chrome extension route.
Use the extension route above when you want to reuse your open login.
For an export-only fallback use an owner-provided CSV/JSON input.
