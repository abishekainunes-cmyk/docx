/* NUNES Existing Chrome connector — no password, OTP or cookie APIs. */
"use strict";
const LOCAL="http://127.0.0.1:8765";
const MAX_PAGES=100;
const MAX_SCAN_MS=12*60*1000;

function onSellerTab(url){
  try{
    const u=new URL(url||"");
    return u.protocol==="https:"&&
      (u.hostname==="indiamart.com"||u.hostname.endsWith(".indiamart.com")) &&
      !/(\/login|\/signin|\/sign-in|\/auth|\/verify)(\/|$)/i.test(u.pathname);
  }catch(_){return false;}
}
function isManageTab(url){
  return onSellerTab(url)&&/manageproducts|manage-products|my-products|myproducts|product-list|product|catalog|seller/i.test(String(url));
}
async function localCall(route,code,data){
  const cleanCode=String(code||"").trim().replace(/^["']|["']$/g,"");
  if(cleanCode.length<24)throw Error("Enter the pairing code shown in the NUNES Windows runner.");
  let response;
  try{
    response=await fetch(LOCAL+route,{
      method:data===undefined?"GET":"POST",cache:"no-store",
      headers:{"X-Nunes-Local-Key":cleanCode,"Content-Type":"application/json"},
      ...(data===undefined?{}:{body:JSON.stringify(data)}),
      signal:AbortSignal.timeout(9000)
    });
  }catch(_){
    throw Error("Local Windows bridge is offline. Start RUN_EXISTING_CHROME_CONNECTOR.bat and keep it open.");
  }
  const json=await response.json().catch(()=>({}));
  if(!response.ok)throw Error(json.error||("Local bridge rejected the request ("+response.status+")."));
  return json;
}
async function saved(){return chrome.storage.local.get(["pairCode","hourlyEnabled","activeRun","pausedRun","lastScan"]);}

async function getStatus(){
  const prefs=await saved();
  let receiver=null;
  let onManageTab=false;
  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(tab&&isManageTab(tab.url))onManageTab=true;
  }catch(_){}
  if(prefs.pairCode){
    try{receiver=await localCall("/status",prefs.pairCode);}
    catch(e){receiver={receiver:"offline",message:e.message};}
  }
  return {paired:Boolean(prefs.pairCode),hourlyEnabled:Boolean(prefs.hourlyEnabled),
          activeRun:prefs.activeRun||null,pausedRun:prefs.pausedRun||null,
          lastScan:prefs.lastScan||null,onManageTab,receiver};
}
async function begin(tab,manual=true){
  const opts=await saved();
  if(!opts.pairCode)throw Error("Pair the extension with your NUNES Windows runner first.");
  if(!tab||!Number.isInteger(tab.id)||!onSellerTab(tab.url))
    throw Error("Open your already logged-in IndiaMART seller Manage Products tab first.");
  if(!isManageTab(tab.url))
    throw Error("Open your authorized Seller Manage Products tab first. This connector does not scan ordinary public IndiaMART or unrelated account pages.");
  if(opts.pausedRun)throw Error("A scan is paused. Click Resume or Stop before starting a new scan.");
  if(opts.activeRun && Date.now()-opts.activeRun.startedAt<MAX_SCAN_MS)
    throw Error("A seller scan is already running. Wait or press Stop Scan.");
  await localCall("/begin",opts.pairCode,{});
  const run={tabId:tab.id,startedAt:Date.now(),pages:0,signatures:[],
             manual:Boolean(manual),maxPages:MAX_PAGES};
  await chrome.storage.local.set({activeRun:run});
  try{
    await chrome.tabs.sendMessage(tab.id,{type:"NUNES_START_SCAN"});
  }catch(_){
    await chrome.storage.local.remove("activeRun");
    throw Error("Refresh the existing IndiaMART Manage Products tab, then press Scan. Chrome extensions cannot read a tab opened before the extension was enabled.");
  }
  return {started:true,message:"Scanning only the authorized, logged-in seller tab. No new login is required."};
}
async function stopScan(reason="Stopped by user",generate=false){
  const data=await saved();
  const run=data.activeRun||data.pausedRun;
  if(!run)return {stopped:true,message:"No scan is running."};
  await chrome.storage.local.remove(["activeRun","pausedRun"]);
  let result={stopped:true,message:reason};
  if(run.pages>0){
    try{
      const count=await localCall("/complete",data.pairCode,{generate:Boolean(generate)});
      result={...result,captured_products:count.captured_products,pdf_state:count.pdf_state};
    }catch(e){result.message+=" "+e.message;}
  }
  await chrome.storage.local.set({lastScan:{at:new Date().toISOString(),
    pages:run.pages,message:result.message}});
  return result;
}
async function pageCaptured(sender,request){
  const data=await saved(),run=data.activeRun;
  if(!run||sender.tab?.id!==run.tabId)
    throw Error("This is not the tab selected for the current read-only scan.");
  if(Date.now()-run.startedAt>MAX_SCAN_MS){
    await stopScan("Scan time limit reached; saved available pages.",true);
    return {advance:false,done:true};
  }
  const page=String(request.page_url||"");
  if(!onSellerTab(page))throw Error("Refusing content from another website.");
  const signature=String(request.signature||"").slice(0,180);
  if(!signature){
    await stopScan("Completed: unrecognized product page.",true);
    return {advance:false,done:true};
  }
  if(run.signatures.includes(signature)){
    // A resumed scan may encounter its most recently captured page again.
    // Skip that already checkpointed page ONCE, then follow Next safely.
    if(run.resumed&&signature===run.signatures[run.signatures.length-1]&&
       request.hasNext&&run.pages<MAX_PAGES){
      run.resumed=false;
      await chrome.storage.local.set({activeRun:run});
      return {advance:true,done:false,pages:run.pages};
    }
    await stopScan("Completed: no new product page discovered.",true);
    return {advance:false,done:true};
  }
  run.resumed=false;
  const products=Array.isArray(request.products)?request.products:[];
  if(!products.length){
    await stopScan("No recognized product titles on this page; verify Manage Products is open.",true);
    return {advance:false,done:true};
  }
  const local=await localCall("/page",data.pairCode,{page_url:page,products});
  run.pages++;
  run.signatures.push(signature);
  if(run.signatures.length>MAX_PAGES)run.signatures.shift();
  await chrome.storage.local.set({activeRun:run});
  if(!request.hasNext||run.pages>=MAX_PAGES){
    const final=await stopScan("Completed "+run.pages+" page(s).",true);
    return {advance:false,done:true,products:local.captured_products,
            status:final.message};
  }
  return {advance:true,done:false,products:local.captured_products,pages:run.pages};
}
async function pauseScan(){
  const opts=await saved();
  if(!opts.activeRun)return {paused:Boolean(opts.pausedRun),
    message:"No active scan to pause."};
  await chrome.storage.local.set({pausedRun:opts.activeRun});
  await chrome.storage.local.remove("activeRun");
  return {paused:true,message:"Scan paused safely. Captured pages remain in the local checkpoint; use Resume to continue."};
}
async function resumeScan(){
  const opts=await saved();
  const run=opts.pausedRun;
  if(!run)throw Error("No paused scan to resume.");
  if(!opts.pairCode)throw Error("The local connector must be paired to resume.");
  const receiver=await localCall("/status",opts.pairCode);
  if(receiver.pdf_state!=="scanning")
    throw Error("The local bridge was restarted. Click Stop and start a new scan; the previous saved product export remains intact.");
  let tab;
  try{tab=await chrome.tabs.get(run.tabId);}
  catch(_){throw Error("The original IndiaMART tab was closed. Click Stop and start a new scan in your signed-in seller tab.");}
  if(!onSellerTab(tab.url))
    throw Error("Return to the original authorized IndiaMART Manage Products tab before resuming.");
  const continued={...run,resumed:true,startedAt:Date.now()};
  await chrome.storage.local.set({activeRun:continued});
  await chrome.storage.local.remove("pausedRun");
  try{await chrome.tabs.sendMessage(run.tabId,{type:"NUNES_START_SCAN"});}
  catch(_){
    await chrome.storage.local.set({pausedRun:run});
    await chrome.storage.local.remove("activeRun");
    throw Error("Refresh the original seller tab, then Resume the scan.");
  }
  return {resumed:true,message:"Resumed the authorized tab without clearing captured product checkpoints."};
}
async function handler(message,sender){
  if(type==="NUNES_PAIR"){
    const code=String(message.code||"").trim().replace(/^["']|["']$/g,"");
    if(!code)throw Error("Enter the pairing code shown in the Windows runner.");
    try{
      await localCall("/pair",code,{code});
    }catch(_){
      await localCall("/status",code);
    }
    await chrome.storage.local.set({pairCode:code});
    return {paired:true,status:await getStatus()};
  }
  if(type==="NUNES_OPEN_FOLDER"){
    const opts=await saved();
    if(opts.pairCode){
      return localCall("/open-folder",opts.pairCode,{}).catch(()=>({}));
    }
    return {};
  }
  if(type==="NUNES_STATUS")return getStatus();
  if(type==="NUNES_SET_HOURLY"){
    const hourlyEnabled=Boolean(message.enabled);
    await chrome.storage.local.set({hourlyEnabled});
    if(hourlyEnabled)await chrome.alarms.create("nunesSellerHourly",{periodInMinutes:60});
    else await chrome.alarms.clear("nunesSellerHourly");
    return {enabled:hourlyEnabled};
  }
  if(type==="NUNES_START"){
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    return begin(tab,true);
  }
  if(type==="NUNES_STOP")return stopScan("Scan stopped by user; captured pages saved.",true);
  if(type==="NUNES_PAUSE")return pauseScan();
  if(type==="NUNES_RESUME")return resumeScan();
  if(type==="NUNES_IS_ACTIVE"){
    const run=(await saved()).activeRun;
    return {active:Boolean(run&&run.tabId===sender.tab?.id&&
             Date.now()-run.startedAt<MAX_SCAN_MS)};
  }
  if(type==="NUNES_CAPTURE_PAGE")return pageCaptured(sender,message);
  if(type==="NUNES_SCAN_FAILED"){
    const run=(await saved()).activeRun;
    if(run&&run.tabId===sender.tab?.id)
      return stopScan("Scan could not continue: "+String(message.message||"unknown error").slice(0,150),true);
  }
  throw Error("Unknown or unauthorized connector command.");
}
chrome.runtime.onMessage.addListener((message,sender,respond)=>{
  handler(message,sender).then(result=>respond({ok:true,result}))
    .catch(e=>respond({ok:false,error:String(e.message||e).slice(0,250)}));
  return true;
});
chrome.alarms.onAlarm.addListener(async alarm=>{
  if(alarm.name!=="nunesSellerHourly")return;
  const state=await saved();
  if(!state.hourlyEnabled||!state.pairCode||
     state.pausedRun||
     (state.activeRun&&Date.now()-state.activeRun.startedAt<MAX_SCAN_MS))return;
  const tabs=await chrome.tabs.query({url:["https://*.indiamart.com/*"]});
  const tab=tabs.find(t=>isManageTab(t.url));
  if(tab){
    try{await begin(tab,false);}
    catch(error){
      await chrome.storage.local.set({lastScan:{at:new Date().toISOString(),
        message:"Hourly scan could not start: "+String(error.message).slice(0,160)}});
    }
  }
});
chrome.runtime.onInstalled.addListener(async()=>{
  const options=await saved();
  if(options.hourlyEnabled)await chrome.alarms.create("nunesSellerHourly",{periodInMinutes:60});
});
