/* NUNES read-only IndiaMART product-list scanner (existing user Chrome tab).
   No cookies, localStorage, account names, OTPs, leads, or private HTML sent.
   It only reads visible product title anchors, matching image URLs and the
   current page address for local origin validation. Next-page click is limited
   to unambiguous pagination controls; it never clicks edit/save/delete.
*/
"use strict";
(()=>{
 const MAX_WAIT=12000;
 let inProgress=false;
 const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 const clean=s=>String(s||"").replace(/\s+/g," ").trim();
 function sellerPage(){
   try{const u=new URL(location.href);
     return u.protocol==="https:"&&
       (u.hostname==="indiamart.com"||u.hostname.endsWith(".indiamart.com"))&&
       !/(\/login|\/signin|\/sign-in|\/auth|\/verify)(\/|$)/i.test(u.pathname);
   }catch(_){return false;}
 }
 function readRows(){
   const found=[],seen=new Set();
   const links=document.querySelectorAll(
     'a[id^="itemName"], a[href*="/proddetail/"], a[href*="/product/"]');
   for(const a of links){
     const title=clean(a.textContent||a.getAttribute("title")||a.getAttribute("aria-label"));
     if(title.length<5||title.length>180)continue;
     const href=String(a.href||"").trim();
     const holder=a.closest('tr,li,article,[class*="MPSD_pdetls"],[class*="product"],[class*="item"]')
       ||a.parentElement;
     let photo="";
     for(const img of holder?.querySelectorAll("img")||[]){
       const raw=img.currentSrc||img.src||img.dataset.src||"";
       if(raw.startsWith("https://")&&
          (img.naturalWidth>55 || !img.complete || img.getAttribute("data-src"))) {
         photo=raw;break;
       }
     }
     const id=/^itemName[0-9]{1,20}$/i.test(a.id||"")?a.id:"";
     const key=(id||title.toLowerCase())+"|"+href;
     if(seen.has(key))continue;
     seen.add(key);
     found.push({product:title,source_url:href,image_link:photo,item_id:id});
     if(found.length>=250)break;
   }
   return found;
 }
 function signature(rows){
   let hash=2166136261;
   const source=rows.map(row=>row.product+"|"+row.source_url).join("\n").slice(0,100000);
   for(let i=0;i<source.length;i++){
     hash^=source.charCodeAt(i);
     hash=Math.imul(hash,16777619);
   }
   return String((hash>>>0).toString(16))+"-"+rows.length;
 }
 function validNext(target){
   if(!target||target.disabled||target.getAttribute("aria-disabled")==="true")return false;
   if(target.closest('[hidden],[aria-hidden="true"]'))return false;
   const style=getComputedStyle(target);
   if(style.visibility==="hidden"||style.display==="none")return false;
   if(target instanceof HTMLAnchorElement&&target.href){
     try{
       const u=new URL(target.href);
       const current=new URL(location.href);
       if(u.origin!==current.origin && !["#","javascript:"].includes(target.getAttribute("href")||"")){
         return false;
       }
     }catch(_){return false;}
   }
   return target.getClientRects().length>0;
 }
 function findNext(){
   const precise=[
     'a[rel="next"]','a[aria-label="Next"]','button[aria-label="Next"]',
     '[data-testid="next-page"]','[aria-label="Next page"]',
     '.pagination a.next','.pagination button.next',
     '.paginator a.next','.paginator button.next'
   ];
   for(const selector of precise){
     const node=document.querySelector(selector);
     if(validNext(node))return node;
   }
   const pager=document.querySelector('[class*="pagination"],[class*="paginator"],[role="navigation"][aria-label*="page" i]');
   if(pager){
     for(const node of pager.querySelectorAll("a,button")){
       if(/^(next|next page|>)$/i.test(clean(node.textContent))&&validNext(node))return node;
     }
   }
   return null;
 }
 async function send(type,fields={}){
   const reply=await chrome.runtime.sendMessage({type,...fields});
   if(!reply?.ok)throw Error(reply?.error||"NUNES local connection is not ready.");
   return reply.result;
 }
 async function waitForChanged(before){
   const deadline=Date.now()+MAX_WAIT;
   while(Date.now()<deadline){
     await pause(450);
     if(!sellerPage())return false;
     const after=readRows();
     if(after.length && signature(after)!==before)return true;
   }
   return false;
 }
 async function collect(){
   if(inProgress)return;
   inProgress=true;
   try{
     if(!sellerPage())throw Error("Open your authorized seller Manage Products tab.");
     let rows=readRows();
     for(let attempt=0;!rows.length&&attempt<9;attempt++){
       await pause(550);rows=readRows();
     }
     if(!rows.length)throw Error("No product-name links found. Open IndiaMART Seller → Manage Products and reload this tab.");
     const stamp=signature(rows);
     const next=findNext();
     const state=await send("NUNES_CAPTURE_PAGE",{
       page_url:location.href,products:rows,signature:stamp,hasNext:Boolean(next)
     });
     if(!state.advance)return;
     if(!next)return;
     next.click(); // unambiguous pagination only; never seller edit/save/delete.
     const changed=await waitForChanged(stamp);
     if(changed){
       inProgress=false;
       await pause(300);
       collect(); // same-document SPA navigation
       return;
     }
     // For document navigations the old content script is destroyed and
     // the new content script automatically resumes via IS_ACTIVE.
     const active=await send("NUNES_IS_ACTIVE").catch(()=>({active:false}));
     if(active.active){
       await send("NUNES_SCAN_FAILED",{
         message:"Next page did not load within 12 seconds; captured pages were saved."
       });
     }
   }catch(error){
     try{await send("NUNES_SCAN_FAILED",{message:String(error.message||error).slice(0,180)});}
     catch(_){}
   }finally{inProgress=false;}
 }
 chrome.runtime.onMessage.addListener((msg,_sender,respond)=>{
   if(msg?.type==="NUNES_START_SCAN"){
     respond({ok:true,started:true});
     setTimeout(collect,300);
   }
 });
 // Resume the same opted-in scan after a full document navigation.
 // A different IndiaMART tab must NEVER capture under this session.
 setTimeout(async()=>{
   try{
     const state=await send("NUNES_IS_ACTIVE");
     if(state.active)await collect();
   }catch(_){}
 },1350);
})();
