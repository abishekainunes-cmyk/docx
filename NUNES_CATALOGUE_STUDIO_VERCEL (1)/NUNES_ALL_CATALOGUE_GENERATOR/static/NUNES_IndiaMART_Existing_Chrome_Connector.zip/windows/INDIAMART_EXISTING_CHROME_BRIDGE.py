#!/usr/bin/env python3
"""NUNES IndiaMART existing-Chrome bridge. Read-only, loopback-only.

A user-installed Chrome extension captures only visible Manage Products titles,
public product URLs and photo URLs from their ALREADY signed-in seller tab.
No Playwright profile copy, passwords, OTP, cookies, customer data or tokens
are read from IndiaMART or sent to the cloud. A local secret pairs the
extension with this local receiver; product data remains local except when
the user enables NUNES's existing PDF-generation workflow.
"""
from __future__ import annotations
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit
import argparse
import hmac
import json
import os
import re
import secrets
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from seller_account import is_public_listing_url, read_records

DEFAULT_SITE="https://nunes-catalogue-studio-live.vercel.app"
WEB_ORIGIN="https://nunes-catalogue-studio-live.vercel.app"
PORT=8765
EXTENSION_ORIGIN=re.compile(r"^chrome-extension://[a-p]{32}$")
SAFE_ID=re.compile(r"^itemName[0-9]{1,20}$",re.I)

def stamp():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")
def _safe_url(url, public_listing=False):
    try:
        url=str(url or "").strip()
        parsed=urlsplit(url)
        if parsed.scheme!="https" or not parsed.hostname or parsed.username or parsed.password:
            return ""
        if public_listing and not is_public_listing_url(url):
            return ""
        # Auth tickets, search arguments and signed personal URL params are not
        # needed for product names or the local PDF generator.
        return parsed._replace(query="",fragment="").geturl()[:1200]
    except ValueError:
        return ""
def seller_page(url):
    try:
        p=urlsplit(str(url or ""))
        host=(p.hostname or "").lower()
        return p.scheme=="https" and not p.username and not p.password and (
            host=="indiamart.com" or host.endswith(".indiamart.com")
        ) and not re.search(r"/(login|signin|sign-in|verify|auth)(?:/|$)",p.path,re.I)
    except ValueError:
        return False
def is_login_page(url):
    try:
        p=urlsplit(str(url or ""))
        return bool(re.search(r"/(login|signin|sign-in|verify|auth)(?:/|$)",p.path,re.I))
    except ValueError:
        return False
def clean_product(row):
    if not isinstance(row,dict):return None
    # Whitelist exact fields: NEVER persist arbitrary webpage data.
    name=re.sub(r"\s+"," ",str(row.get("product") or "")).strip()[:180]
    if not 5<=len(name)<=180:return None
    if re.search(r"(?i)(?:\bpassword\b|\bverification code\b|\bOTP\b|\baccount settings\b)",name):
        return None
    source=_safe_url(row.get("source_url"),public_listing=True)
    image=_safe_url(row.get("image_link"))
    item_id=str(row.get("item_id") or "").strip()[:40]
    key=item_id if SAFE_ID.fullmatch(item_id) else ""
    model=re.sub(r"\s+"," ",str(row.get("source_model") or row.get("model") or "")).strip()[:110]
    brand=re.sub(r"\s+"," ",str(row.get("source_brand") or row.get("brand") or "")).strip()[:120]
    desc=re.sub(r"\s+"," ",str(row.get("description") or "")).strip()[:3600]
    specs=str(row.get("specifications") or "")[:6000]
    result={"product":name,"source_url":source,"image_link":image,
            "source_model":model,"source_brand":brand,"description":desc,"specifications":specs,
            "catalogue_brand":"VTech","catalogue_model":"VT",
            "source":"authorized_existing_chrome_seller_page"}
    if key:result["source_id"]=key
    return result
def json_file(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    pending=path.with_suffix(path.suffix+".tmp")
    pending.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    pending.replace(path)
def data_root():
    return Path(os.getenv("LOCALAPPDATA") or (Path.home()/".local"/"share"))/"NunesCatalogue"/"IndiaMART"/"ExistingChrome"

class State:
    def __init__(self,folder,site):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True)
        self.site=site.rstrip("/")
        self.output=self.folder/"Catalogues"
        self.output.mkdir(parents=True,exist_ok=True)
        self.capture=self.folder/"seller_products.json"
        self.scan_checkpoint=self.folder/"scan-checkpoint.json"
        self.connection_file=self.folder/"connection-status.json"
        self.pair_file=self.folder/"local-pairing.json"
        self.lock=threading.RLock()
        self.rows={}              # last committed, never wiped by a failed scan
        self.scan_rows={}         # temporary current scan data
        self.page_count=0
        self.last_scan=""
        self.last_extension_auth=""
        self.paired_this_run=False
        self.last_successful_scan=""
        self.sync_state="idle"
        self.last_error=""
        self.last_report={}
        try:
            report_file=self.output/"last-report.json"
            if report_file.is_file():
                loaded=json.loads(report_file.read_text(encoding="utf-8"))
                if isinstance(loaded,dict):
                    self.last_report=loaded
        except (OSError,ValueError,TypeError):
            pass
        try:
            saved_status=json.loads(self.connection_file.read_text(encoding="utf-8"))
            if isinstance(saved_status,dict):
                self.last_successful_scan=str(saved_status.get("last_successful_scan") or "")
        except (OSError,ValueError,TypeError):
            pass
        self.running=False
        self.started=False
        try:
            pairing=json.loads(self.pair_file.read_text(encoding="utf-8"))
            secret=pairing.get("local_key","")
            self.secret=secret if len(secret)>=24 else secrets.token_urlsafe(24)
        except (OSError,ValueError,TypeError):
            self.secret=secrets.token_urlsafe(24)
        json_file(self.pair_file,{"local_key":self.secret,"created_at":stamp(),
                                 "warning":"For the local NUNES Chrome extension ONLY; never send to a website."})
        if self.capture.is_file():
            try:
                old=read_records(self.capture.read_bytes(),self.capture.name)
                for p in old:self.rows[(p["product"].casefold(),p.get("source_url") or "")]=p
            except (OSError,ValueError):
                pass
    def authorized(self,value):
        val=str(value or "").strip().strip('"').strip("'")
        valid=hmac.compare_digest(val,self.secret)
        if valid:
            with self.lock:
                self.paired_this_run=True
                self.last_extension_auth=stamp()
        return valid
    def _connection_snapshot(self):
        return {"updated_at":stamp(),"receiver":"ready",
                "extension_paired":self.paired_this_run,
                "captured_products":len(self.rows),
                "pages_scanned_this_run":self.page_count,
                "last_successful_scan":self.last_successful_scan,
                "pdf_state":self.sync_state,
                "last_error":self.last_error,
                "output_folder":str(self.output)}
    def _save_connection(self):
        json_file(self.connection_file,self._connection_snapshot())
    def begin(self):
        with self.lock:
            # Stage a new scan without touching the previous committed export.
            # Login failure, empty pages and cancellation cannot erase it.
            self.scan_rows={}
            self.page_count=0
            self.started=True
            self.last_error=""
            self.sync_state="scanning"
            self._save_connection()
    def page(self,page_url,rows):
        if not seller_page(page_url):
            raise ValueError("Only your open, authorized IndiaMART seller page can be scanned.")
        if not isinstance(rows,list) or len(rows)>260:
            raise ValueError("A scan page must contain at most 260 product rows.")
        with self.lock:
            if not self.started:
                raise ValueError("Start an authorized scan before submitting product pages.")
            count=0
            for raw in rows:
                parsed=clean_product(raw)
                if not parsed:continue
                key=(parsed["product"].casefold(),parsed["source_url"])
                if key not in self.scan_rows:count+=1
                self.scan_rows[key]=parsed
            if not self.scan_rows:
                raise ValueError("This page contains no recognizable product rows.")
            self.page_count+=1
            self.last_scan=stamp()
            # An interrupted scan can resume manually without losing pages.
            json_file(self.scan_checkpoint,{
                "updated_at":self.last_scan,
                "pages_scanned":self.page_count,
                "products":list(self.scan_rows.values())})
            self._save_connection()
            return count
    def snapshot(self,public=False):
        with self.lock:
            actual_count=len(self.scan_rows) if self.started else len(self.rows)
            conn_state="Local Runner Ready"
            if self.sync_state=="scanning":
                conn_state="Scanning"
            elif self.sync_state=="generating":
                conn_state="Generating PDFs"
            elif self.sync_state in ("finished","captured"):
                conn_state="Completed"
            elif self.last_error:
                conn_state="Needs Attention"
            elif self.paired_this_run:
                conn_state="Extension Paired"
            elif int(self.last_report.get("full_available",self.last_report.get("full_created",0)) or 0)>0:
                conn_state="Completed"
            state={"receiver":"running","account_connected":bool(
                       (self.page_count>0 and actual_count>0) or (actual_count>0 and self.last_successful_scan)),
                   "connection_state":conn_state,
                   "catalogue_brand":"VTech",
                   "catalogue_model":"VT",
                   "extension_paired":self.paired_this_run,
                   "captured_products":actual_count,
                   "saved_products":len(self.rows),
                   "pages_scanned":self.page_count,
                   "last_capture":self.last_scan,
                   "last_successful_scan":self.last_successful_scan,
                   "pdf_state":self.sync_state,
                   "pdf_counts":{
                       "full_created":int(self.last_report.get(
                           "full_available",self.last_report.get("full_created",0)) or 0),
                       "mini_created":int(self.last_report.get(
                           "mini_available",self.last_report.get("mini_created",0)) or 0),
                       "needs_review":int(self.last_report.get(
                           "needs_review_total",self.last_report.get("needs_review",0)) or 0),
                       "drive_saved":int(self.last_report.get("drive_saved_count",0))},
                   "drive_full_folder":"https://drive.google.com/drive/folders/1wdEVHTs14IW8Dm-1-2hUebUw-hv8mUgF",
                   "drive_mini_folder":"https://drive.google.com/drive/folders/1vKbU4e_16f1rO9-U1bPofRiDrUqiaS2C",
                   "output_folder":str(self.output),
                   "message":("Product rows captured from the authorized Chrome extension."
                              if self.page_count and actual_count else
                              "Receiver ready; waiting for an authorized seller-page scan.")}
            if not public:
                state["last_error"]=self.last_error
                state["last_report"]={k:v for k,v in self.last_report.items()
                                      if k in ("total_product_rows","full_created","mini_created",
                                               "publish_review_needed","needs_review","timestamp")}
            return state
    def complete(self,generate=True):
        with self.lock:
            if not self.started or not self.scan_rows:
                raise ValueError("No valid new scan was captured. Previous products remain unchanged.")
            # Merge rather than replace: a partial pagination run or network
            # failure must never delete any previously captured product.
            self.rows.update(self.scan_rows)
            payload={"format":"nunes-owner-seller-list-v1","created_at":stamp(),
                     "products":list(self.rows.values()),
                     "note":"Read-only collection from user-authorized existing Chrome. No cookies/OTP captured."}
            json_file(self.capture,payload)
            self.last_successful_scan=stamp()
            self.scan_rows={}
            self.started=False
            self.sync_state="queued" if generate else "captured"
            self._save_connection()
            if generate and not self.running:
                self.running=True
                thread=threading.Thread(target=self._generate,daemon=True,name="NUNES Catalogue Sync")
                thread.start()
    def auto_sync(self):
        with self.lock:
            if self.running:
                return {"running":True,"message":"Catalogue generation is already in progress."}
            if not self.rows and self.capture.is_file():
                try:
                    old=read_records(self.capture.read_bytes(),self.capture.name)
                    for p in old:self.rows[(p["product"].casefold(),p.get("source_url") or "")]=p
                except Exception:pass
            if not self.rows:
                return {"running":False,"message":"No product records found to generate catalogues. Scan seller products from the Chrome extension."}
            self.running=True
            self.sync_state="generating"
            thread=threading.Thread(target=self._generate,daemon=True,name="NUNES Catalogue Sync")
            thread.start()
            return {"running":True,"message":"Background catalogue sync started."}
    def _generate(self):
        with self.lock:
            self.sync_state="generating"
            self._save_connection()
        try:
            import requests  # only needed when generating PDFs
            from INDIAMART_ACCOUNT_SYNC import run_once
            result=run_once(self.capture,self.output,self.site,only_changed=True)
            with self.lock:
                self.last_report=result
                self.sync_state="finished"
                self.last_error=""
                self._save_connection()
        except Exception as exc:
            with self.lock:
                self.sync_state="error"
                self.last_error=str(exc)[:280]
                self._save_connection()
        finally:
            with self.lock:self.running=False

class Receiver(BaseHTTPRequestHandler):
    server_version="NUNES-IndiaMART-Local/1.0"
    def log_message(self,fmt,*args):
        # Never log authorization headers, query values, cookies or page data.
        print("[%s] "%stamp()+fmt%args,flush=True)
    def _cors(self):
        origin=self.headers.get("Origin","").strip()
        if origin:
            is_ext=(
                origin.lower().startswith("chrome-extension://") or
                origin.lower().startswith("moz-extension://") or
                origin.lower().startswith("edge-extension://") or
                origin.lower().startswith("extension://") or
                EXTENSION_ORIGIN.fullmatch(origin) is not None
            )
            if is_ext or (self.path=="/health" and origin==WEB_ORIGIN):
                self.send_header("Access-Control-Allow-Origin",origin)
                self.send_header("Vary","Origin")
                self.send_header("Access-Control-Allow-Methods","GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers","X-Nunes-Local-Key, Content-Type, Access-Control-Request-Private-Network")
                self.send_header("Access-Control-Allow-Private-Network","true")
                self.send_header("Access-Control-Max-Age","600")
    def reply(self,status,payload):
        encoded=json.dumps(payload,ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type","application/json; charset=utf-8")
        self.send_header("Cache-Control","no-store")
        self.send_header("X-Content-Type-Options","nosniff")
        self._cors()
        self.send_header("Content-Length",str(len(encoded)))
        self.end_headers()
        self.wfile.write(encoded)
    def do_OPTIONS(self):
        if self.path not in ("/health","/status","/begin","/page","/complete","/pair","/open-folder","/auto-sync","/api/auto-scrape"):
            self.reply(404,{"error":"Unknown endpoint"});return
        origin=self.headers.get("Origin","").strip()
        if origin:
            is_ext=(
                origin.lower().startswith("chrome-extension://") or
                origin.lower().startswith("moz-extension://") or
                origin.lower().startswith("edge-extension://") or
                origin.lower().startswith("extension://") or
                EXTENSION_ORIGIN.fullmatch(origin) is not None
            )
            if not is_ext and not (self.path=="/health" and origin==WEB_ORIGIN):
                self.reply(403,{"error":"Only the installed NUNES extension can send scans."});return
        self.send_response(204)
        self._cors()
        self.send_header("Content-Length","0")
        self.end_headers()
    def _auth(self):
        origin=self.headers.get("Origin","").strip()
        if origin:
            is_ext=(
                origin.lower().startswith("chrome-extension://") or
                origin.lower().startswith("moz-extension://") or
                origin.lower().startswith("edge-extension://") or
                origin.lower().startswith("extension://") or
                EXTENSION_ORIGIN.fullmatch(origin) is not None
            )
            if not is_ext and origin!=WEB_ORIGIN:
                return False
        return self.server.state.authorized(self.headers.get("X-Nunes-Local-Key"))
    def do_GET(self):
        if self.path.startswith("/catalogues/"):
            from urllib.parse import unquote
            subpath=unquote(self.path[len("/catalogues/"):].lstrip("/"))
            target=(self.server.state.output / subpath).resolve()
            if self.server.state.output.resolve() not in target.parents or not target.is_file():
                self.reply(404,{"error":"Catalogue file not found"})
                return
            try:
                pdf_bytes=target.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type","application/pdf")
                self.send_header("Content-Disposition",f'inline; filename="{target.name}"')
                self.send_header("Content-Length",str(len(pdf_bytes)))
                self.send_header("Cache-Control","no-cache")
                self._cors()
                self.end_headers()
                self.wfile.write(pdf_bytes)
                return
            except Exception as e:
                self.reply(500,{"error":str(e)})
                return
        if self.path in ("/","/index.html"):
            from html import escape as html_escape
            state=self.server.state.snapshot(public=True)
            current=html_escape(str(state.get("connection_state") or "Ready"))
            captured=int(state.get("captured_products") or 0)
            exported=int((state.get("pdf_counts") or {}).get("full_created") or 0)
            mini=int((state.get("pdf_counts") or {}).get("mini_created") or 0)
            drive_saved=int((state.get("pdf_counts") or {}).get("drive_saved") or 0)
            out_folder=str(self.server.state.output)
            
            full_items=[]
            cat_p=self.server.state.output/"Catalogue"
            if cat_p.is_dir():
                for f in sorted(cat_p.glob("*.pdf")):
                    kb=f.stat().st_size/1024
                    full_items.append(f'<li><span class="file-name">{html_escape(f.name)}</span> <span class="file-meta">({kb:.0f} KB)</span> <a href="/catalogues/Catalogue/{html_escape(f.name)}" target="_blank" class="file-btn">Open PDF</a></li>')
            
            mini_items=[]
            mini_p=self.server.state.output/"Mini Catalogue"
            if mini_p.is_dir():
                for f in sorted(mini_p.glob("*.pdf")):
                    kb=f.stat().st_size/1024
                    mini_items.append(f'<li><span class="file-name">{html_escape(f.name)}</span> <span class="file-meta">({kb:.0f} KB)</span> <a href="/catalogues/Mini%20Catalogue/{html_escape(f.name)}" target="_blank" class="file-btn">Open PDF</a></li>')
            
            full_html="".join(full_items) if full_items else '<li class="empty-list">No Full Catalogues generated yet</li>'
            mini_html="".join(mini_items) if mini_items else '<li class="empty-list">No Mini Catalogues generated yet</li>'
            
            page="""<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>NUNES Local Connector · Running</title>
<style>
body{font:15px system-ui,Segoe UI,Arial,sans-serif;background:#f4f7fd;color:#213a5b;margin:0;padding:clamp(18px,4vw,40px)}
main{max-width:820px;background:#fff;border:1px solid #dce6f3;border-radius:17px;padding:28px;margin:auto;box-shadow:0 8px 25px #172e4c0c}
h1{font-size:25px;margin:0 0 6px}h2{font-size:17px;margin:18px 0 10px;color:#18365f}
p{line-height:1.6;color:#536985;margin:8px 0}
.flag{display:inline-block;padding:7px 13px;margin:10px 0 16px;border-radius:7px;background:#e9f8ee;color:#246b3d;font-weight:700}
.metrics{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:16px 0}
.metric{border:1px solid #d9e6f5;background:#f8fbff;border-radius:9px;padding:14px;text-align:center}
.metric b{font-size:26px;display:block;color:#164f9a;margin-bottom:2px}
.metric small{font-size:12px;color:#6b7b8c;font-weight:600}
.actions{display:flex;flex-wrap:wrap;gap:10px;margin:18px 0}
.btn{background:#0e60d2;color:#fff;border:none;border-radius:8px;padding:10px 16px;font-size:14px;font-weight:600;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;transition:background .2s}
.btn:hover{background:#0b4fb1}
.btn.secondary{background:#eef4fd;color:#164f9a;border:1px solid #c8dcf7}
.btn.secondary:hover{background:#dfeafb}
.file-section{margin-top:20px;border:1px solid #e2eaf4;border-radius:10px;padding:16px;background:#fafcff}
.file-list{list-style:none;padding:0;margin:10px 0 0;max-height:260px;overflow-y:auto}
.file-list li{display:flex;align-items:center;justify-content:space-between;padding:8px 10px;border-bottom:1px solid #edf2f8;font-size:13px}
.file-list li:last-child{border-bottom:none}
.file-name{font-weight:600;color:#1d3557;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:68%}
.file-meta{color:#788ea6;font-size:12px}
.file-btn{background:#e7f0fd;color:#0e60d2;padding:4px 9px;border-radius:5px;text-decoration:none;font-weight:600;font-size:12px}
.file-btn:hover{background:#d5e5fc}
.empty-list{color:#8ea3b8;font-style:italic;padding:8px 0}
a{color:#1455b6;font-weight:700}code{background:#eaf2fc;padding:2px 5px;border-radius:4px}
footer{margin-top:24px;border-top:1px solid #edf1f6;padding-top:14px;font-size:12px;color:#788ea6}
</style>
</head><body><main>
<h1>NUNES IndiaMART Local Connector</h1>
<div class="flag" id="conn-flag">● Local receiver running — """+current+"""</div>
<p>Windows receiver is online and synchronized with your local IndiaMART Chrome session. Generated catalogue PDFs remain safely on this computer and upload automatically to Google Drive.</p>
<div class="metrics">
  <div class="metric"><b id="metric-captured">"""+str(captured)+"""</b><small>Captured products</small></div>
  <div class="metric"><b id="metric-full">"""+str(exported)+"""</b><small>Full PDFs</small></div>
  <div class="metric"><b id="metric-mini">"""+str(mini)+"""</b><small>Mini PDFs</small></div>
  <div class="metric"><b id="metric-drive" style="color:#0f8b44">"""+str(drive_saved)+"""</b><small>Google Drive Saved</small></div>
</div>
<div class="actions">
  <button id="btn-open-folder" class="btn secondary">📂 Open Output Folder</button>
  <button id="btn-auto-sync" class="btn">⚡ Run Automatic Sync / Refresh</button>
  <a href="https://drive.google.com/drive/folders/1wdEVHTs14IW8Dm-1-2hUebUw-hv8mUgF" target="_blank" rel="noopener noreferrer" class="btn secondary">📁 Drive Catalogue Folder</a>
  <a href="https://drive.google.com/drive/folders/1vKbU4e_16f1rO9-U1bPofRiDrUqiaS2C" target="_blank" rel="noopener noreferrer" class="btn secondary">📁 Drive Mini Folder</a>
  <a href="https://nunes-catalogue-studio-live.vercel.app/mini-catalogue" target="_blank" class="btn secondary">🌐 Instant Cloud Studio</a>
</div>

<div class="file-section" style="background:#f0f6ff;border-color:#b9d5fb">
  <h2>⚡ Instant IndiaMART Scrape & Generate to Google Drive</h2>
  <p style="margin:4px 0 12px">Enter any product name or IndiaMART URL to automatically scrape specifications, render 2-page PDF, and upload directly to Google Drive:</p>
  <div style="display:flex;gap:10px;align-items:center">
    <input id="scrape-input" type="text" placeholder="e.g. Elemental Analyzer CS1000 or paste IndiaMART URL..." style="flex:1;padding:10px 14px;border:1px solid #b8d2f5;border-radius:8px;font-size:14px">
    <button id="btn-scrape-now" class="btn" style="white-space:nowrap">🚀 Scrape & Save to Drive</button>
  </div>
  <div id="scrape-status" style="margin-top:10px;font-size:13px;display:none;padding:10px;border-radius:6px"></div>
</div>

<div class="file-section">
  <h2>Full Catalogues ("""+str(len(full_items))+""")</h2>
  <ul class="file-list">"""+full_html+"""</ul>
</div>
<div class="file-section">
  <h2>Mini Catalogues ("""+str(len(mini_items))+""")</h2>
  <ul class="file-list">"""+mini_html+"""</ul>
</div>
<footer><a href="/health">Machine-readable /health</a> · Output: """+html_escape(out_folder)+"""</footer>
</main>
<script>
document.getElementById('btn-open-folder').onclick=function(){
  fetch('/open-folder',{method:'POST'}).then(r=>r.json()).then(d=>{console.log('Opened',d)}).catch(e=>console.error(e));
};
document.getElementById('btn-auto-sync').onclick=function(){
  var b=this;b.disabled=true;b.textContent='Starting sync...';
  fetch('/auto-sync',{method:'POST'}).then(r=>r.json()).then(d=>{
    alert(d.message);setTimeout(function(){location.reload()},1200);
  }).catch(function(e){alert('Sync error: '+e);b.disabled=false;b.textContent='⚡ Run Automatic Sync / Refresh'});
};
document.getElementById('btn-scrape-now').onclick=function(){
  var q=document.getElementById('scrape-input').value.trim();
  if(!q){alert('Enter a product name or IndiaMART URL');return}
  var b=this,s=document.getElementById('scrape-status');
  b.disabled=true;b.textContent='Scraping & Generating...';
  s.style.display='block';s.style.background='#eef4fd';s.style.color='#164f9a';
  s.textContent='Scraping IndiaMART listing, formatting specifications, and generating catalogue...';
  fetch('/api/auto-scrape',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({query:q})})
  .then(function(r){return r.json()})
  .then(function(d){
    b.disabled=false;b.textContent='🚀 Scrape & Save to Drive';
    if(d.success){
      s.style.background='#e9f8ee';s.style.color='#186333';
      var driveMsg=d.drive_saved?' & Saved to Google Drive!':' (Generated locally)';
      var linkHtml=(d.drive_links&&d.drive_links.full)?' · <a href="'+d.drive_links.full+'" target="_blank">Open in Google Drive</a>':'';
      s.innerHTML='<b>Success!</b> Generated: '+d.product+driveMsg+linkHtml;
      setTimeout(function(){location.reload()},2500);
    }else{
      s.style.background='#fdf0ed';s.style.color='#a32a14';
      s.textContent='Failed: '+(d.error||'Unknown error');
    }
  }).catch(function(err){
    b.disabled=false;b.textContent='🚀 Scrape & Save to Drive';
    s.style.background='#fdf0ed';s.style.color='#a32a14';
    s.textContent='Error: '+err;
  });
};
setInterval(function(){
  fetch('/health').then(function(r){return r.json()}).then(function(d){
    var flag=document.getElementById('conn-flag');
    if(flag&&d.connection_state)flag.textContent='● Local receiver running — '+d.connection_state;
    var c=document.getElementById('metric-captured');
    if(c&&typeof d.captured_products==='number')c.textContent=d.captured_products;
    var f=document.getElementById('metric-full');
    if(f&&d.pdf_counts&&typeof d.pdf_counts.full_created==='number')f.textContent=d.pdf_counts.full_created;
    var m=document.getElementById('metric-mini');
    if(m&&d.pdf_counts&&typeof d.pdf_counts.mini_created==='number')m.textContent=d.pdf_counts.mini_created;
    var dr=document.getElementById('metric-drive');
    if(dr&&d.pdf_counts&&typeof d.pdf_counts.drive_saved==='number')dr.textContent=d.pdf_counts.drive_saved;
  }).catch(function(){});
},3000);
</script>
</body></html>"""
            encoded=page.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type","text/html; charset=utf-8")
            self.send_header("Cache-Control","no-store")
            self.send_header("X-Content-Type-Options","nosniff")
            self.send_header("Content-Security-Policy",
                             "default-src 'self' 'unsafe-inline' https://nunes-catalogue-studio-live.vercel.app; "
                             "script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
                             "base-uri 'none'; form-action 'none'")
            self.send_header("Content-Length",str(len(encoded)))
            self.end_headers()
            self.wfile.write(encoded)
            return
        if self.path=="/health":
            self.reply(200,self.server.state.snapshot(public=True));return
        if self.path=="/open-folder":
            folder=str(self.server.state.output)
            try:
                if os.name=="nt":os.startfile(folder)
                elif sys.platform=="darwin":import subprocess;subprocess.Popen(["open",folder])
                else:import subprocess;subprocess.Popen(["xdg-open",folder])
                self.reply(200,{"opened":True,"path":folder})
            except Exception as e:
                self.reply(500,{"error":f"Could not open folder: {e}","path":folder})
            return
        if self.path=="/status":
            if not self._auth():
                self.reply(403,{"error":"Pairing code did not match. Please copy the code printed in your Windows terminal window."});return
            self.reply(200,self.server.state.snapshot());return
        self.reply(404,{"error":"Unknown endpoint"})
    def do_POST(self):
        if self.path=="/open-folder":
            folder=str(self.server.state.output)
            try:
                if os.name=="nt":os.startfile(folder)
                elif sys.platform=="darwin":import subprocess;subprocess.Popen(["open",folder])
                else:import subprocess;subprocess.Popen(["xdg-open",folder])
                self.reply(200,{"opened":True,"path":folder})
            except Exception as e:
                self.reply(500,{"error":f"Could not open folder: {e}","path":folder})
            return
        if self.path=="/auto-sync":
            res=self.server.state.auto_sync()
            self.reply(200,res)
            return
        if self.path=="/api/auto-scrape":
            try:
                length=int(self.headers.get("Content-Length","0"))
                body=json.loads(self.rfile.read(length)) if length>0 else {}
            except Exception:body={}
            query=str(body.get("query") or "").strip()
            if not query:
                self.reply(400,{"error":"Product query is required."});return
            try:
                import requests
                res = requests.post(self.server.state.site + "/api/catalogue/auto-generate",
                                    json={"query": query, "save_drive": True},
                                    timeout=(10, 120))
                if res.status_code == 200:
                    self.reply(200, res.json())
                else:
                    self.reply(res.status_code, {"error": f"Auto-generation failed: {res.text[:200]}"})
            except Exception as e:
                self.reply(500, {"error": f"Scrape error: {str(e)}"})
            return
        if self.path=="/pair":
            try:
                length=int(self.headers.get("Content-Length","0"))
                body=json.loads(self.rfile.read(length)) if length>0 else {}
            except Exception:body={}
            code=str(body.get("code") or self.headers.get("X-Nunes-Local-Key") or "")
            if self.server.state.authorized(code):
                self.reply(200,{"paired":True,"status":self.server.state.snapshot()})
            else:
                self.reply(403,{"error":"Pairing code did not match. Check the code printed in the Windows runner terminal window."})
            return
        if self.path not in ("/begin","/page","/complete"):
            self.reply(404,{"error":"Unknown endpoint"});return
        if not self._auth():
            self.reply(403,{"error":"Pair the installed Chrome extension with your local runner."});return
        try:length=int(self.headers.get("Content-Length","0"))
        except ValueError:length=-1
        if length<0 or length>512000:
            self.reply(413,{"error":"Product scan request is too large."});return
        try:
            body=json.loads(self.rfile.read(length))
            if not isinstance(body,dict):raise ValueError("Invalid scan request.")
            if self.path=="/begin":
                self.server.state.begin()
            elif self.path=="/page":
                self.server.state.page(body.get("page_url"),body.get("products"))
            else:
                self.server.state.complete(bool(body.get("generate",True)))
            self.reply(200,self.server.state.snapshot())
        except (ValueError,TypeError) as exc:
            self.reply(422,{"error":str(exc)[:220]})

class SingleInstanceServer(ThreadingHTTPServer):
    allow_reuse_address=False

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--port",type=int,default=PORT)
    ap.add_argument("--folder",default=str(data_root()))
    ap.add_argument("--site",default=DEFAULT_SITE)
    args=ap.parse_args()
    if not 1025<=args.port<=65535:
        raise SystemExit("Port must be between 1025 and 65535.")
    if args.site!=DEFAULT_SITE:
        raise SystemExit("For security, use the official NUNES Catalogue Studio endpoint.")
    state=State(args.folder,args.site)
    try:server=SingleInstanceServer(("127.0.0.1",args.port),Receiver)
    except OSError as exc:
        print("\n==============================================================")
        print(" NUNES CONNECTOR IS ALREADY RUNNING on http://127.0.0.1:%s"%args.port)
        print(" Your existing runner is already active and ready.")
        print(" Keep the existing runner window open, or close it to restart.")
        print("==============================================================\n")
        raise SystemExit(0)
    server.daemon_threads=True
    server.state=state
    print("\n==============================================================")
    print(" NUNES - REUSE YOUR EXISTING INDIAMART CHROME LOGIN")
    print("==============================================================")
    print(" LOCAL ONLY: http://127.0.0.1:%s"%args.port)
    print(" Pairing code (enter ONCE in the Chrome extension popup):")
    print(" "+state.secret)
    print(" Keep this terminal open while automatic scans are enabled.")
    print(" Open the normal Chrome window where IndiaMART is ALREADY logged in.")
    print(" No Chrome profile copy, password, OTP, cookie, or sign-in required.")
    print(" Output folder:",state.output)
    print(" Press Ctrl+C to stop.\n")
    try:server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:pass
    finally:server.server_close()
if __name__=="__main__":main()
