#!/usr/bin/env python3
r"""Authorized IndiaMART seller export -> NUNES Full/Mini PDF sync.

Runs on YOUR Windows PC. It does not ask for, upload, or export IndiaMART
passwords, OTPs, cookies or tokens. Only your product export/catalogue
details are sent to your configured NUNES Catalogue Studio for rendering.

Usage:
  py windows/INDIAMART_ACCOUNT_SYNC.py --input "C:\Nunes\IndiaMART Products.csv"
  py windows/INDIAMART_ACCOUNT_SYNC.py --input "C:\Nunes\IndiaMART Products.csv" --watch-seconds 3600
  py windows/INDIAMART_ACCOUNT_SYNC.py --capture-seller --input account_products.json

Optional --capture-seller opens a dedicated visible Chrome window with a
persistent local profile. Login normally once on the official seller site and
open Manage Products. With --watch-seconds, this SAME Chrome window stays open
for timed read-only refreshes, subject to IndiaMART's own session expiration.
No credentials, cookies, OTPs or private account secrets are uploaded.
"""
from __future__ import annotations
import argparse
import base64
import csv
import json
import hashlib
import os
from pathlib import Path
import re
import sys
import time
from urllib.parse import urlsplit
from datetime import datetime,timezone

APP_ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(APP_ROOT))
from seller_account import read_records,fingerprint,is_public_listing_url

DEFAULT_SITE="https://nunes-catalogue-studio-live.vercel.app"
def timestamp():return datetime.now(timezone.utc).isoformat(timespec="seconds")
def safe_filename(value):
    return re.sub(r"[^A-Za-z0-9 _-]","",str(value))[:65].strip() or "product"
def save_json(path,value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding="utf-8")
    tmp.replace(path)
def check_site(site):
    parsed=urlsplit(site)
    if parsed.scheme!="https" or not parsed.hostname or parsed.username or parsed.password:
        raise ValueError("Specify an HTTPS NUNES Catalogue Studio URL")
    return site.rstrip("/")
def _seller_url(value):
    """Accept only public IndiaMART seller navigation, never auth query data."""
    parsed=urlsplit(str(value or "").strip())
    host=(parsed.hostname or "").lower()
    if (parsed.scheme!="https" or parsed.username or parsed.password or not (
        host=="indiamart.com" or host.endswith(".indiamart.com")
    )):
        return ""
    # User IDs, login tickets and other URL query values are not checkpoints.
    return parsed._replace(query="",fragment="").geturl()


def _choose_seller_tab(context):
    """Prefer the already visible Manage Products page after manual sign-in."""
    candidates=[]
    for tab in context.pages:
        url=_seller_url(tab.url)
        if not url:
            continue
        try:
            has_products=tab.locator(
                'a[href*="/proddetail/"],a[href*="/product/"],a[id^="itemName"]'
            ).count()>0
        except Exception:
            has_products=False
        if has_products:
            return tab
        if any(term in url.casefold() for term in (
                'manageproducts','product-list','myproducts','my-products')):
            candidates.insert(0,tab)
        else:
            candidates.append(tab)
    return candidates[0] if candidates else (
        context.pages[-1] if context.pages else context.new_page())


def seller_capture(destination,profile,base_url,max_pages=150,
                   interactive=True,context=None):
    """Capture only seller-visible product rows, never authentication data.

    When context is supplied, Chrome remains open between timed scans, so
    the browser session stays active while IndiaMART considers it valid.
    Both workflows use a SEPARATE dedicated Chrome profile on the local PC.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise SystemExit(
            "Install Playwright once: py -m pip install requests playwright"
        ) from exc
    safe_base=_seller_url(base_url)
    if not safe_base:
        raise ValueError("Seller URL must use the official HTTPS indiamart.com domain")
    profile=Path(profile).expanduser().resolve()
    profile.mkdir(parents=True,exist_ok=True)
    checkpoint_url_file=Path(str(destination)+".seller-list-url.json")
    pw=None
    browser=context
    created=context is None
    if created:
        pw=sync_playwright().start()
        try:
            browser=pw.chromium.launch_persistent_context(
                user_data_dir=str(profile),channel="chrome",headless=False,
                viewport={"width":1450,"height":900},accept_downloads=False)
        except Exception:
            pw.stop()
            raise
    found={}
    try:
        page=_choose_seller_tab(browser)
        if not interactive and checkpoint_url_file.is_file():
            try:
                checkpoint=json.loads(
                    checkpoint_url_file.read_text(encoding="utf-8"))
                candidate=_seller_url(checkpoint.get("list_url"))
                if candidate:
                    safe_base=candidate
            except (ValueError,OSError):
                pass
        # During the first login, keep any already-open authorized seller tab
        # instead of replacing it with the dashboard home page.
        if interactive:
            page.goto(safe_base,wait_until="domcontentloaded",timeout=30000)
            print("\nNUNES IndiaMART: normal seller-account sign-in")
            print("Use the official IndiaMART website in this dedicated Chrome window.")
            print("Complete any password, OTP or other login challenge THERE, not here.")
            print("Navigate to your OWN Manage Products list before continuing.")
            print("This local tool reads only product names, public links and images.")
            input("After the Manage Products list is visible, press Enter here: ")
            page=_choose_seller_tab(browser)
            current_url=_seller_url(page.url)
            if current_url:
                save_json(checkpoint_url_file,{"list_url":current_url})
        else:
            page.goto(safe_base,wait_until="domcontentloaded",timeout=30000)
            print("Rechecking seller products with the same local Chrome session.")
        # Avoid silently treating a sign-in page as an empty product export.
        url=_seller_url(page.url)
        login_words=('/login','/signin','/sign-in','/auth/','/verify')
        if not url or any(x in url.casefold() for x in login_words):
            print("INDIAMART SIGN-IN REQUIRED. The session may have expired.")
            print("Sign in normally and restart the Windows runner if necessary.")
            return 0
        for page_no in range(1,max_pages+1):
            if page_no>1:
                page.wait_for_timeout(900)
            rows=page.evaluate(r"""() => {
              const result=[];const seen=new Set();
              for(const a of document.querySelectorAll(
                'a[href*="/proddetail/"],a[href*="/product/"],a[id^="itemName"]')) {
                const title=(a.textContent||a.getAttribute('title')||'')
                    .replace(/\s+/g,' ').trim();
                if(title.length<5||title.length>180)continue;
                const href=a.href||'';
                const key=title.toLowerCase()+'|'+href;
                if(seen.has(key))continue;
                seen.add(key);
                const holder=a.closest(
                    'tr,li,article,[class*=product],[class*=item]'
                )||a.parentElement;
                const picture=holder?.querySelector('img[src]')?.src||'';
                result.push({product:title,source_url:href,
                             image_link:picture,source:'owner_seller_list'});
              }
              return result.slice(0,250);
            }""")
            fresh=0
            for row in rows:
                name=re.sub(r"\s+"," ",str(row.get("product") or "")).strip()
                if len(name)<5:
                    continue
                url=str(row.get("source_url") or "")
                if not is_public_listing_url(url):
                    url=""
                img=str(row.get("image_link") or "")
                if not img.startswith("https://"):
                    img=""
                key=(name.casefold(),url)
                if key in found:
                    continue
                found[key]={"product":name,"source_url":url,
                            "image_link":img,"status":"captured",
                            "source":"authorized_seller_dom"}
                fresh+=1
            if not rows:
                print("No recognizable product names on this page.")
                print("Open your seller Manage Products list and retry.")
                break
            save_json(destination,{
                "format":"nunes-owner-seller-list-v1",
                "created_at":timestamp(),
                "products":list(found.values()),
                "note":"Read-only seller product names; exact-source details still require review."
            })
            print(f"Page {page_no}: +{fresh} products; {len(found)} total")
            # Read-only, explicitly-labelled next page only; never modify
            # IndiaMART products or submit edit/save/delete actions.
            next_button=page.locator(
                'a[rel="next"],a[aria-label="Next"],button[aria-label="Next"]'
            ).first
            if not next_button.count() or not next_button.is_visible() or not next_button.is_enabled():
                print("No clear Next button. Scan ended at this page.")
                break
            old_url=page.url
            next_button.click(timeout=4500)
            try:
                page.wait_for_load_state("domcontentloaded",timeout=10000)
            except Exception:
                pass
            if page.url==old_url and fresh==0:
                print("No new product rows after Next; scan complete.")
                break
            time.sleep(0.75)
        if not found:
            print("No captured rows. Existing local product data remains unchanged.")
        else:
            print(f"Captured {len(found)} product names to {destination}")
        return len(found)
    finally:
        if created:
            browser.close()
            pw.stop()


def run_persistent_seller_watch(args):
    """Login once; keep ONE dedicated Chrome window open during repeated scans.

    No IndiaMART account password, cookie, OTP or browser storage is uploaded
    to the hosted site. The browser retains its own local session while valid.
    """
    try:
        from playwright.sync_api import sync_playwright
    except ImportError as exc:
        raise SystemExit(
            "First install: py -m pip install requests playwright"
        ) from exc
    profile=Path(args.profile).expanduser().resolve()
    profile.mkdir(parents=True,exist_ok=True)
    destination=Path(args.input)
    destination.parent.mkdir(parents=True,exist_ok=True)
    with sync_playwright() as pw:
        try:
            browser=pw.chromium.launch_persistent_context(
                user_data_dir=str(profile),channel="chrome",headless=False,
                viewport={"width":1450,"height":900},accept_downloads=False)
        except Exception as exc:
            raise RuntimeError(
                "Could not open dedicated Chrome profile; close any other "
                "NUNES IndiaMART runner, then retry. "+str(exc)[:200]) from exc
        try:
            initial=True
            while True:
                try:
                    count=seller_capture(
                        destination,args.profile,args.seller_url,
                        args.max_seller_pages,interactive=initial,
                        context=browser)
                    initial=False
                    if count>0 and destination.is_file():
                        run_once(destination,args.output,args.site,
                                 args.max_items,args.mini_size)
                    else:
                        print("Seller product list not available. No PDFs will "
                              "be generated from stale or empty results.")
                        print("If logged out, sign in on the visible Chrome "
                              "window and restart this runner.")
                except KeyboardInterrupt:
                    break
                except Exception as exc:
                    print("Sync attempt failed: "+str(exc),file=sys.stderr)
                if not args.watch_seconds:
                    break
                print(f"Signed-in Chrome stays open. Next read-only check in "
                      f"{args.watch_seconds} seconds. Press Ctrl+C to stop.")
                try:
                    time.sleep(args.watch_seconds)
                except KeyboardInterrupt:
                    break
        finally:
            browser.close()


def request_json(session,url,data):
    result=session.post(url,json=data,timeout=(10,105),
                        headers={"X-Nunes-AI-Request":"1","Content-Type":"application/json"})
    if result.status_code!=200:
        try:reason=result.json().get("error","")
        except ValueError:reason=result.text[:150]
        raise RuntimeError(f"HTTP {result.status_code}: {reason}")
    return result.json()
def download_pdf(session,url,data,path,code=""):
    headers={"Content-Type":"application/json"}
    headers["X-Nunes-Drive-Save"]="1"
    if code and len(code)>=16:
        headers["X-Nunes-Drive-Token"]=code
    pairing_file=Path.home()/"AppData/Local/NunesCatalogue/IndiaMART/ExistingChrome/local-pairing.json"
    if pairing_file.is_file():
        try:
            k=json.loads(pairing_file.read_text(encoding="utf-8")).get("local_key","")
            if k:headers["X-Nunes-Local-Key"]=k
        except Exception:pass
    r=session.post(url,json=data,headers=headers,timeout=(10,115))
    if r.status_code!=200 or not r.content.startswith(b"%PDF"):
        try:message=r.json().get("error","Not PDF")
        except ValueError:message=r.text[:180]
        raise RuntimeError(f"HTTP {r.status_code}: {message}")
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(".pdf.part")
    temporary.write_bytes(r.content)
    temporary.replace(path)
    drive_link=r.headers.get("X-Nunes-Drive-Link") or ""
    return {"saved_to_drive":r.headers.get("X-Nunes-Drive-Status")=="saved",
            "drive_link":drive_link,
            "pages":r.headers.get("X-Nunes-Page-Count","")}
def download_review_draft(session,site,item,path):
    """Use the tested eight-item Full batch renderer to create ONE clearly
    labelled, non-publishable review PDF even without complete source facts.
    """
    import io
    import zipfile
    response=session.post(
        site+"/api/catalogue/full-batch",
        json={"products":[{
            "product":item["product"],
            "model":item.get("source_model") or "",
            "source_url":item.get("source_url") or "",
            "image_link":item.get("image_link") or "",
            "source":"owner_seller_export",
        }]},
        headers={"Content-Type":"application/json",
                 "X-Nunes-AI-Request":"1"},
        timeout=(10,115))
    if response.status_code!=200 or not response.content.startswith(b"PK"):
        try:message=response.json().get("error","ZIP not returned")
        except ValueError:message=response.text[:150]
        raise RuntimeError("Review draft failed: "+str(message)[:180])
    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        pdf_names=[name for name in archive.namelist()
                   if name.lower().endswith(".pdf")]
        if len(pdf_names)!=1:
            raise RuntimeError("Review ZIP must contain one Full PDF")
        bytes_pdf=archive.read(pdf_names[0])
        if not bytes_pdf.startswith(b"%PDF"):
            raise RuntimeError("Review ZIP did not contain a valid PDF")
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(".pdf.part")
    temporary.write_bytes(bytes_pdf)
    temporary.replace(path)
    return {"pages":2,"source_evidence_review_required":True}

def valid_saved_pdf(path):
    """Never trust a completed checkpoint if its actual PDF disappeared."""
    try:
        item=Path(str(path or ""))
        if not item.is_file() or item.stat().st_size<100:return False
        with item.open("rb") as handle:return handle.read(5)==b"%PDF-"
    except (OSError,ValueError):return False


def run_once(source,output,site,max_items=0,mini_size=12,only_changed=True):
    import requests
    source=Path(source);output=Path(output)
    if not source.is_file():raise FileNotFoundError(str(source))
    records=read_records(source.read_bytes(),source.name)
    output.mkdir(parents=True,exist_ok=True)
    checkpoint=output/"sync-checkpoint.json"
    old=json.loads(checkpoint.read_text(encoding="utf-8")) if checkpoint.is_file() else {}
    done=old.get("done",{})
    mini_done=old.get("mini_done",{})
    problems=[]
    results=[]
    changed=[]
    session=requests.Session()
    drive_code=os.environ.get("NUNES_DRIVE_SAVE_CODE","")
    for item in records:
        if max_items and len(changed)>=max_items:break
        digest=fingerprint(item)
        source_id=item["source_id"]
        prev=done.get(source_id,{})
        if (only_changed and prev.get("fingerprint")==digest and
            prev.get("status") in ("ready","review_draft") and
            valid_saved_pdf(prev.get("pdf"))):
            results.append({"product":item["product"],"status":"unchanged",
                            "pdf":prev.get("pdf"),"source_id":source_id,
                            "catalogue_brand":"VTech","catalogue_model":"VT"})
            continue
        changed.append(item)
        print(f"[{len(changed)}] {item['product']}",flush=True)
        entry={"product":item["product"],"source_id":source_id,
               "source_model":item["source_model"],
               "catalogue_brand":"VTech","catalogue_model":"VT",
               "source_url":item["source_url"]}
        try:
            prepared=request_json(session,site+"/api/catalogue/batch/prepare",{
                "product":item["product"],"model":item["source_model"],
                "source_url":item["source_url"],
                "scraped":{
                   "status":"captured","product":item["product"],
                   "model":item["source_model"],
                   "source_url":item["source_url"],
                   "description":item["description"],
                   "specifications":item["specifications"],
                   "image_link":item["image_link"],
                } if item["source_url"] and
                  (item["description"] or item["specifications"]) else None,
                "batch_code":drive_code
            })
            entry["source_specs"]=prepared["specification_count"]
            entry["source_method"]=prepared["source_method"]
            entry["image_available"]=bool(prepared["image_link"])
            filename=safe_filename(item["product"])+"_"+source_id+".pdf"
            full_path=output/"Catalogue"/filename
            ready=bool(prepared.get("full_ready"))
            failed_reason=""
            if ready:
                try:
                    meta=download_pdf(session,site+"/api/generate",{
                        "type":"full","product":prepared["product"],
                        "model":prepared["source_model"],
                        "specifications":prepared["specifications"],
                        "description":prepared["description"],
                        "features":"\n".join(prepared["features"]),
                        "image_link":prepared["image_link"]
                    },full_path,drive_code)
                    entry.update(status="ready",pdf=str(full_path),**meta)
                except Exception as error:
                    failed_reason="Source-backed Full layout unavailable: "+str(error)[:120]
                    ready=False
            if not ready:
                # Every account product gets a real two-page Full PDF. Without
                # sourced values, it is deliberately marked NOT FOR PUBLICATION.
                meta=download_review_draft(session,site,item,full_path)
                entry.update(status="review_draft",pdf=str(full_path),**meta)
                entry["note"]=failed_reason or (
                    "No complete exact-product source specification/photo; "
                    "draft must be verified before sharing.")
                problems.append(entry.copy())
            done[source_id]={"fingerprint":digest,"status":entry["status"],
                             "last_synced":timestamp(),"pdf":str(full_path),
                             "drive_link":entry.get("drive_link","")}
            entry["prepared"]=prepared
        except Exception as exc:
            entry["status"]="failed"
            entry["error"]=str(exc)[:220]
            problems.append(entry.copy())
            done[source_id]={"fingerprint":digest,"status":"failed",
                             "last_synced":timestamp()}
        results.append(entry)
        save_json(checkpoint,{"updated_at":timestamp(),"done":done,
                              "mini_done":mini_done})
        time.sleep(0.5)
    # Mini catalogues cover all selected source product names in manageable
    # batches; remote image hosts may decline fetching photos and remain names.
    # Rebuild only when products changed. Large accounts do not require one
    # giant PDF or one long-running Vercel serverless request.
    mini_results=[]
    batches=[records[i:i+mini_size] for i in range(0,len(records),mini_size)]
    for index,group in enumerate(batches,1):
        if not group:continue
        group_id=str(index)
        chosen=group[0]
        file=output/"Mini Catalogue"/(
            "VTech_VT_Products_"+str(index).zfill(3)+".pdf")
        group_fp=hashlib.sha256(json.dumps([
            [p["source_id"],fingerprint(p)] for p in group
        ],ensure_ascii=False,separators=(",",":")).encode("utf-8")).hexdigest()
        prev_mini=mini_done.get(group_id,{})
        if (only_changed and prev_mini.get("fingerprint")==group_fp and
            prev_mini.get("status")=="ready" and valid_saved_pdf(file)):
            mini_results.append({"batch":index,"status":"unchanged",
                                 "pdf":str(file)})
            continue
        data={"type":"mini","product":chosen["product"],
              "model":chosen["source_model"],
              "image_link":chosen["image_link"],
              "related":[
                  {"product":p["product"],"model":p["source_model"],
                   "image_link":p["image_link"],
                   "source_url":p["source_url"]}
                  for p in group[1:]],
              "keywords":""}
        try:
            details=download_pdf(session,site+"/api/generate",data,file,drive_code)
            mini_results.append({"batch":index,"status":"ready",
                                 "pdf":str(file),**details})
            mini_done[group_id]={"fingerprint":group_fp,"status":"ready",
                                 "pdf":str(file),"last_synced":timestamp()}
        except Exception as exc:
            mini_results.append({"batch":index,"status":"failed",
                                 "error":str(exc)[:180]})
            mini_done[group_id]={"fingerprint":group_fp,"status":"failed",
                                 "pdf":str(file),"last_synced":timestamp()}
        save_json(checkpoint,{"updated_at":timestamp(),"done":done,
                              "mini_done":mini_done})
    summary={
        "timestamp":timestamp(),"source_file":str(source),
        "total_product_rows":len(records),"changed_or_retry":len(changed),
        "full_created":sum(x.get("status") in ("ready","review_draft") for x in results),
        "full_available":sum(1 for value in done.values()
            if value.get("status") in ("ready","review_draft")
            and valid_saved_pdf(value.get("pdf"))),
        "publish_review_needed":sum(x.get("status")=="review_draft" for x in results),
        "needs_review":len(problems),
        "needs_review_total":sum(
            value.get("status")=="review_draft" for value in done.values()),
        "mini_created":sum(x["status"]=="ready" for x in mini_results),
        "mini_available":sum(1 for value in mini_done.values()
            if value.get("status")=="ready"
            and valid_saved_pdf(value.get("pdf"))),
        "drive_saved_count":sum(bool(x.get("drive_link") or x.get("saved_to_drive")) for x in results),
        "drive_mini_saved_count":sum(bool(x.get("drive_link") or x.get("saved_to_drive")) for x in mini_results),
        "results":results,"mini":mini_results,
        "note":"VTech/VT are NUNES catalogue fields, not original manufacturer/model. Unverified source values need review."
    }
    # Avoid copying huge descriptive content or credentials into report.
    for item in summary["results"]:item.pop("prepared",None)
    save_json(output/"last-report.json",summary)
    print(f"Done: {len(records)} input items; {summary['full_created']} Full PDFs; "
          f"{summary['mini_created']} Mini PDFs; {len(problems)} requiring review.")
    return summary
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input",default="",help="Optional owner CSV/JSON, or local captured seller products")
    parser.add_argument("--output",default="NUNES_Account_Catalogues")
    parser.add_argument("--site",default=DEFAULT_SITE)
    parser.add_argument("--max-items",type=int,default=0)
    parser.add_argument("--mini-size",type=int,default=12)
    parser.add_argument("--watch-seconds",type=int,default=0,
                        help="Reread the export periodically to pick up new/changed items")
    parser.add_argument("--capture-seller",action="store_true",
                        help="Open local Chrome for read-only seller list capture")
    parser.add_argument("--seller-url",default="https://seller.indiamart.com/")
    parser.add_argument("--profile",default=str(
        Path.home()/".nunes_indiamart_readonly_profile"))
    parser.add_argument("--max-seller-pages",type=int,default=100)
    args=parser.parse_args()
    args.site=check_site(args.site)
    if not args.input:
        if args.capture_seller:
            args.input=str(Path(args.output)/"seller_products.json")
        else:
            parser.error("Provide --input for an owner CSV/JSON export, or use --capture-seller to sign in normally")
    if not 1<=args.mini_size<=30:
        raise SystemExit("--mini-size must be 1 to 30")
    if args.watch_seconds and args.watch_seconds<300:
        raise SystemExit("Minimum watch interval is 300 seconds")
    if args.capture_seller:
        # In watch mode Chrome stays open, keeping the same local session
        # for repeat read-only scans. One-off capture also uses the same profile.
        run_persistent_seller_watch(args)
        return
    while True:
        try:
            run_once(args.input,args.output,args.site,args.max_items,args.mini_size)
        except KeyboardInterrupt:raise
        except Exception as error:print("Sync error: "+str(error),file=sys.stderr)
        if not args.watch_seconds:break
        print(f"Waiting {args.watch_seconds}s; checking the owner export for changes.")
        try:time.sleep(args.watch_seconds)
        except KeyboardInterrupt:break
if __name__=="__main__":
    main()
